/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largestarray;

/**
 *
 * @author Inshara
 */

/**This is the class ReverseNumber used to reverse any number */
public class ReverseNumber {

    /**
     * @param args the command line arguments
     */
    /** this is the main method where we define our code*/
    public static void main(String[] args) {
        // TODO code application logic here
        /**original number */
        /**  number,reverseNumber and temp are variables */
                int number = 1234;
                int reversedNumber = 0;
                int temp = 0;
               /** this is the while loop*/
                while(number > 0){
                       
                        //use modulus operator to strip off the last digit
                        temp = number%10;
                       
                        //create the reversed number
                        reversedNumber = reversedNumber * 10 + temp;
                        number = number/10;
                         
                }
               
                /**output the reversed number */
                /** this is the print statement which is used to print the reversed numbers*/
                System.out.println("Reversed Number is: " + reversedNumber);
    }
    
}
