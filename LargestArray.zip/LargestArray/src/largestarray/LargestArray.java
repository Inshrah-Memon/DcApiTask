/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largestarray;

/**
 *
 * @author Inshara
 */
/** 
	*FindLargestSmallestNumber class is the demo for finding the largest 
	*and smallest number in the array
	*/
public class LargestArray {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
            /**
	*array of 10 numbers
	*/
                int numbers[] = new int[]{32,43,53,54,32,65,63,98,43,23};
               
                 /**
	*assign first element of an array to largest and smallest and then sort it
	*/

                int smallest = numbers[0];
                int largetst = numbers[0];
               
                for(int i=1; i< numbers.length; i++)
                {
                        if(numbers[i] > largetst)
                                largetst = numbers[i];
                        else if (numbers[i] < smallest)
                                smallest = numbers[i];
                       
                }
               
	/**
	*print the largest and smallest number
	*/

                 System.out.println("Largest Number is : " + largetst);
                 System.out.println("Smallest Number is : " + smallest);
    }
    
}
